//
//  AboutVC.swift
//  ScholarSync-Adam
//
//  Created by Adam on 8/20/24.
//

import Foundation
import UIKit

class AboutVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.tintColor = UIColor.white
    }
}
